# hypermedia19
Hypermedia project 2019-2020

#membri del gruppo

Selva Marco - 847171 - 10521418

Tresoldi Andrea - 847387 - 10535801

Zani Simone - 846664 - 10502938


git Repository - https://github.com/marcoselva/hypermedia19


to start: node app.js
to start continuos server: npm start
